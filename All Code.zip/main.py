from math import ceil
import streamlit as st
from PIL import Image
from exapackage.shop import Tokopedia
from exapackage.keys import Tokopedia as TokpedKeys
from exapackage.shopee_global import Shopee
from exapackage.shopee_store_item import store_search
import os
from datetime import datetime
import pandas as pd
import streamlit_authenticator as stauth



names = ['John Smith','Rebecca Briggs']
usernames = ['jsmith','rbriggs']
passwords = ['123','456']


hashed_passwords = stauth.hasher(passwords).generate()

print(hashed_passwords)

authenticator = stauth.authenticate(names,usernames,hashed_passwords,
    'some_cookie_name','some_signature_key',cookie_expiry_days=1)

print(authenticator)

name, authentication_status = authenticator.login('Login','main')


def update_pages():
    st.session_state.page_awal = st.session_state.page

def sort_by(name):
    val = {'Paling Sesuai':23, 'Terbaru':2, 'Harga Tertinggi':10,
            'Harga Terendah':9, 'Ulasan Terbanyak':11, 'Pembelian Terbanyak':8,
            'Dilihat Terbanyak':5, 'Pembaruan Terakhir':3}
    return val[name]

def res_filter(name):
    val = {'Paling Sesuai':23, 'Ulasan':5, 'Terbaru':9,
            'Harga Tertinggi':4, 'Harga Terendah':3}
    
    return val[name]

if authentication_status:
    
    with st.sidebar:
        
        st.markdown("<h1 style='text-align: center;'> EXA x MERCH </h1>", unsafe_allow_html=True)
        option = st.selectbox('Target Website', ['Tokopedia', 'Shopee'])
        print('Refresh Page')
        option2 = st.selectbox('Crawl by: ', ['Keyword', 'Shop Link'])
        if option == 'Tokopedia':
                
            if option2 == 'Keyword':

                keyword = st.text_area('Input Keyword(s)', placeholder='Seperate word by new line')
                keyword = keyword.split('\n')
                keyword = [x for x in keyword if x != '']
                filter_by = st.selectbox('Filter By : ', ['Paling Sesuai', 'Ulasan', 'Terbaru', 'Harga Tertinggi', 'Harga Terendah'])
                info = 0
                total_page = ''
                if keyword:
                    total_page = ''
                    for key in keyword:
                        info = TokpedKeys(Search=key).get_keys_products(sort_val=res_filter(filter_by), pages=1, info=True)
                        total_page = total_page + '%s : %s\n'%(key, info)
                pages = st.text_input('Max pages to be crawled', placeholder='Number only')
                start_crawl = st.button('Scrape Website')
                st.markdown("<h4 style='text-align: center; color: red;'> Single page contain 60 products </h4>", unsafe_allow_html=True)
                st.markdown(f"""
                            ```
                            {total_page}
                            """)

            else:
                shopLink = st.text_input('Shop link address', placeholder='URL')
                st.text_input('Max pages to be crawled', placeholder='Number only', key='page_awal')
                filter_by = st.selectbox('Filter By : ', ['Paling Sesuai', 'Terbaru', 'Harga Tertinggi',
                    'Harga Terendah', 'Ulasan Terbanyak', 'Pembelian Terbanyak',
                    'Dilihat Terbanyak', 'Pembaruan Terakhir'])
                
                shopInfo = st.button('Show Shop Information')
                
                if shopInfo and shopLink:
                    name, loc, prCount, prSold, tx = Tokopedia(Search=shopLink).get_shop_products(info=True)
                    st.text_input('Possible pages to be crawled', placeholder='Max : {}'.format(ceil(int(prCount) / 80)), key='page', on_change=update_pages)
                    
                    
                    print('step 1 : ', st.session_state.page)
                    print('side 1 : ', filter_by)
                    if filter_by == 'Terbaru':
                        filter_by = '2'
                        print('side 2 : ', filter_by)
                start_scraping = st.button('Scrape Website')
                st.markdown("<h4 style='text-align: center; color: red;'> Please notes that scraping with shop address will get single page by default </h4>", unsafe_allow_html=True)
        # =====================================================================================================================================
        # =====================================================================================================================================
        # =====================================================================================================================================
        else:
            if option2 == 'Keyword':

                keyword = st.text_area('Input Keyword(s)', placeholder='Seperate word by new line')
                keyword = keyword.split('\n')
                keyword = [x for x in keyword if x != '']
                filter_by = st.selectbox('Filter By : ', ['Terkait', 'Terbaru', 'Terlaris', 'Termurah', 'Sales', 'Termahal'])
                info = 0
                total_page = ''
                if keyword:
                    total_page = ''
                    for key in keyword:
                        info = Shopee(Search=key).global_search(sort_by_key=filter_by, info=True)
                        total_page = total_page + '%s : %s\n'%(key, info)
                pages = st.text_input('Max pages to be crawled', placeholder='Number only')
                start_crawl = st.button('Scrape Website')
                st.markdown("<h4 style='text-align: center; color: red;'> Single page contain 60 products </h4>", unsafe_allow_html=True)
                st.markdown(f"""
                            ```
                            {total_page}
                            """)

            else:
                shopLink = st.text_input('Shop link address', placeholder='URL')
                keyword = st.text_area('Input Keyword(s)', placeholder='Seperate word by new line')
                keyword = keyword.split('\n')
                keyword = [x for x in keyword if x != '']
                pages = st.text_input('Max pages to be crawled', placeholder='Number only', key='page_awal')
                filter_by = st.selectbox('Filter By : ', ['Terkait', 'Terbaru', 'Terlaris', 'Termurah', 'Sales', 'Termahal'])
                
                shopInfo = st.button('Show Shop Information')
                
                # if shopLink:
                    # name, loc, prCount, prSold, tx = Tokopedia(Search=shopLink).get_shop_products(info=True)
                    # st.text_input('Possible pages to be crawled', placeholder='Max : {}'.format(ceil(int(prCount) / 80)), key='page', on_change=update_pages)
                    
                start_scraping = st.button('Scrape Website')
                st.markdown("<h4 style='text-align: center; color: red;'> Please notes that scraping with shop address will get single page by default </h4>", unsafe_allow_html=True)


    col1, col2, col3 = st.columns(3)
    with col1:
        st.write(' ')
    with col2:
        image = Image.open('logo/images.png')

        st.image(image, caption='EXA x MERCH')

    with col3:
        st.write(' ')

    with st.expander("Spider Bot Details"):
        st.markdown("<h1 style='text-align: center;'> SHOPEDIA SPIDER </h1>", unsafe_allow_html=True)
        st.write("""
                **ver 0.1**
                
                --------------------------------
                
                - [x] Version 0.5
                - [x] Development phase (Current)
                - [ ] Testing Phase
                
                |Website(supported) | Features |
                | ----------- | ----------- |
                |Tokopedia          | Keyword Search , By Store| 
                |Shopee          | Keyword Search, By Store|
                
                --------------------------------------------------------

                """)


    if option2 == 'Keyword':
        if start_crawl:
            now = datetime.now()
            current_time = now.strftime("%Y-%m-%d-%H-%M")
            if option == 'Tokopedia':
                for key in keyword:
                    temp = TokpedKeys(Search=key).get_keys_products(sort_val=res_filter(filter_by), pages=int(pages))
                    temp.to_excel('Data/Tokopedia - %s - %s.xlsx' %(key, current_time), index=False)
            else:
                for key in keyword:
                    temp = Shopee(Search=key).global_search(sort_by_key=filter_by, max_page=int(pages))
                    temp.to_excel('Data/Shopee - %s - %s.xlsx' %(key, current_time), index=False)

        with st.container():
            folder = os.listdir('Data/')
            if folder:
                res = st.selectbox('Dataset', folder)
                df  =  pd.read_excel('Data/'+ res)
                st.write('***Result**' , df)

                data = df.to_csv().encode('utf-8')
                st.download_button("Download here", data=data, file_name=res, mime='text/csv', key='download-csv')
        
        
                
    if option2 == 'Shop Link':
        if shopInfo and shopLink:
            with st.expander('Shop Details'):
                    
                    st.markdown(f"""
                                Shop Info : 

                                ------------------------

                                - Name : {name}
                                - Location : {loc}
                                - Total Products : {prCount}
                                - Products Sold : {prSold}
                                - Transaction Success : {tx}
                                
                                """)

        if start_scraping:
            if option == "Tokopedia":

                try :
                    if st.session_state.page_awal:
                        isSuccess = True
                        df = Tokopedia(Search=shopLink).get_shop_products(page=int(st.session_state.page_awal), sort=sort_by(filter_by))
                    else:
                        isSuccess = True
                        df = Tokopedia(Search=shopLink).get_shop_products(page=1, sort=sort_by(filter_by))
                except:
                    st.error('Please input Shop link address')
                    isSuccess = False
            else:
                now = datetime.now()
                current_time = now.strftime("%Y-%m-%d-%H-%M")
                for key in keyword:

                    temp = store_search(shopLink, key, int(pages), filter_by)
                    temp.to_excel('Data/Shopee - %s - %s.xlsx' %(key, current_time), index=False)

                
            # with st.expander('Result Details'):
                    
            #         st.markdown(f"""
            #                     Parameters : 

            #                     ------------------------
            #                     - Url : {shopLink}
            #                     - Filter By : {filter_by}
            #                     - Scraped Pages : {st.session_state.page_awal}
                                
            #                     """)
            # if isSuccess:
            #     st.write('**Result**', df)

        with st.container():
            folder = os.listdir('Data/')
            if folder:
                res = st.selectbox('Dataset', folder)
                df  =  pd.read_excel('Data/'+ res)
                st.write('***Result**' , df)

                data = df.to_csv().encode('utf-8')
                st.download_button("Download here", data=data, file_name=res, mime='text/csv', key='download-csv')



